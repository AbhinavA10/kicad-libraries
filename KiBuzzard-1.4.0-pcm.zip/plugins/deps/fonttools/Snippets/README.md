This directory includes snippets that people might useful to get ideas from.
The contents will come and go, don't rely on them being there or having a certain API.
If you need it, copy it and modify it.

If you do and think your work is useful for others, please add a link to it here:

* https://github.com/twardoch/fonttools-utils
* https://github.com/twardoch/ttfdiet
* https://github.com/googlei18n/nototools
* https://github.com/googlefonts/fontbakery
* https://github.com/Typefounding/setUseTypoMetricsFalse
* https://github.com/ftCLI/ftCLI
