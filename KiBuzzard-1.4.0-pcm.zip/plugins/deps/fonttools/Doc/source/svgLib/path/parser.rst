######
parser
######

.. automodule:: fontTools.svgLib.path.parser
   :inherited-members:
   :members:
   :undoc-members:
