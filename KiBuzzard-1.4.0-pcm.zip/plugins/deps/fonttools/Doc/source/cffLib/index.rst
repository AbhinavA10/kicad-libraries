##################################
cffLib: read/write Adobe CFF fonts
##################################

.. automodule:: fontTools.cffLib

This package also contains two modules for manipulating CFF format glyphs:

.. toctree::
   :maxdepth: 1

   specializer
   width
