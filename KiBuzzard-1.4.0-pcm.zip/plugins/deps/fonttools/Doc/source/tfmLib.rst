###########################################
tfmLib: Read TeX Font Metrics files
###########################################

.. automodule:: fontTools.tfmLib

.. autoclass:: fontTools.tfmLib.TFM
   :members:
