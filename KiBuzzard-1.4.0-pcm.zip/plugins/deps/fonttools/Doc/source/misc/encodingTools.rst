#############
encodingTools
#############

.. automodule:: fontTools.misc.encodingTools
   :inherited-members:
   :members:
   :undoc-members:
