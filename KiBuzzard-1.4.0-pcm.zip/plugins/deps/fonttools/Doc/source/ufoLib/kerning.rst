
#######
kerning
#######

.. automodule:: fontTools.ufoLib.kerning
   :inherited-members:
   :members:
   :undoc-members:
