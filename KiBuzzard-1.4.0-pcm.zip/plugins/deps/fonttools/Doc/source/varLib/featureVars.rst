###########
featureVars
###########

.. automodule:: fontTools.varLib.featureVars
   :inherited-members:
   :members:
   :undoc-members:
