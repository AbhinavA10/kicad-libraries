####
mvar
####

.. automodule:: fontTools.varLib.mvar
   :inherited-members:
   :members:
   :undoc-members:

.. data:: fontTools.varLib.mvar.MVAR_ENTRIES