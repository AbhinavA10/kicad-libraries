###
cff
###

.. automodule:: fontTools.varLib.cff
   :inherited-members:
   :members:
   :undoc-members:
