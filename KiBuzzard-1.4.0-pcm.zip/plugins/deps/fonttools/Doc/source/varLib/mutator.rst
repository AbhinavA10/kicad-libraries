#######
mutator
#######

.. automodule:: fontTools.varLib.mutator
   :inherited-members:
   :members:
   :undoc-members:
