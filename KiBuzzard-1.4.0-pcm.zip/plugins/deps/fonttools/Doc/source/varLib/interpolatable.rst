##############
interpolatable
##############

.. automodule:: fontTools.varLib.interpolatable
   :inherited-members:
   :members:
   :undoc-members:
