``DSIG``: Digital Signature Table
---------------------------------

.. automodule:: fontTools.ttLib.tables.D_S_I_G_
   :inherited-members:
   :members:
   :undoc-members:

