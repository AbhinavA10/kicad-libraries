``MATH``: Mathematical Typesetting Table
----------------------------------------

.. automodule:: fontTools.ttLib.tables.M_A_T_H_
   :inherited-members:
   :members:
   :undoc-members:
