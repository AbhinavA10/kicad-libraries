``bsln``: Baseline
------------------

.. automodule:: fontTools.ttLib.tables._b_s_l_n
   :inherited-members:
   :members:
   :undoc-members:
