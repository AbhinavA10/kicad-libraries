``VDMX``: Vertical Device Metrics
---------------------------------

.. automodule:: fontTools.ttLib.tables.V_D_M_X_
   :inherited-members:
   :members:
   :undoc-members:
