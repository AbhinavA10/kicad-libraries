``cvar``: CVT Variations Table
------------------------------

.. automodule:: fontTools.ttLib.tables._c_v_a_r
   :inherited-members:
   :members:
   :undoc-members:


TupleVariation
^^^^^^^^^^^^^^

.. automodule:: fontTools.ttLib.tables.TupleVariation
   :noindex:
   :inherited-members:
   :members:
   :undoc-members:
