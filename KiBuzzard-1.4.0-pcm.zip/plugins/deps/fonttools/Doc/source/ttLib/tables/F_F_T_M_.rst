``FFTM``: FontForge Time Stamp Table
------------------------------------

.. automodule:: fontTools.ttLib.tables.F_F_T_M_
   :inherited-members:
   :members:
   :undoc-members:


