``glyf``: Glyph Data
--------------------

.. autoclass:: fontTools.ttLib.tables._g_l_y_f.table__g_l_y_f
   :members:
.. autoclass:: fontTools.ttLib.tables._g_l_y_f.Glyph
   :members:
.. autoclass:: fontTools.ttLib.tables._g_l_y_f.GlyphComponent
   :members:
.. autoclass:: fontTools.ttLib.tables._g_l_y_f.GlyphCoordinates
   :members: array, zeros, copy, __len__, __getitem__, __setitem__, __delitem__, append, extend, toInt, relativeToAbsolute, absoluteToRelative, translate, scale, transform, __pos__, __neg__, __iadd__, __isub__, __imul__, __itruediv__, __bool__
