``prop``: Glyph Properties Table
--------------------------------

.. automodule:: fontTools.ttLib.tables._p_r_o_p
   :inherited-members:
   :members:
   :undoc-members:

