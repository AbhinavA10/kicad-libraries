``CBDT``: Color Bitmap Data Table
---------------------------------

.. automodule:: fontTools.ttLib.tables.C_B_D_T_
   :inherited-members:
   :members:
   :undoc-members:

