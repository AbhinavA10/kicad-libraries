``hhea``: Horizontal Header Table
---------------------------------

.. automodule:: fontTools.ttLib.tables._h_h_e_a
   :inherited-members:
   :members:
   :undoc-members:

