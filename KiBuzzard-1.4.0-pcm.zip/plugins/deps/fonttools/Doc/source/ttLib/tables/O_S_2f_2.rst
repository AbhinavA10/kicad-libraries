``OS/2``: OS/2 and Windows Metrics Table
----------------------------------------

.. automodule:: fontTools.ttLib.tables.O_S_2f_2
   :inherited-members:
   :members:
   :undoc-members:
