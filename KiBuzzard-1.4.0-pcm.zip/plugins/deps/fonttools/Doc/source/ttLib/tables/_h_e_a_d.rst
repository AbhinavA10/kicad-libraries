``head``: Font Header Table
---------------------------

.. automodule:: fontTools.ttLib.tables._h_e_a_d
   :inherited-members:
   :members:
   :undoc-members:

