``maxp``: Maximum Profile
-------------------------

.. automodule:: fontTools.ttLib.tables._m_a_x_p
   :inherited-members:
   :members:
   :undoc-members:

