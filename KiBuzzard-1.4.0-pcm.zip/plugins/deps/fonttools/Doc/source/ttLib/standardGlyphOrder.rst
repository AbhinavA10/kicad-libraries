##################
standardGlyphOrder
##################

.. automodule:: fontTools.ttLib.standardGlyphOrder
   :inherited-members:
   :members:
   :undoc-members:

.. data:: fontTools.ttLib.standardGlyphOrder.standardGlyphOrder

A Python list of "standard" glyphs required by post table formats 1.0 and 2.0.
