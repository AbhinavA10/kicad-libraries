############
ttCollection
############

.. automodule:: fontTools.ttLib.ttCollection
   :inherited-members:
   :members:
   :undoc-members: