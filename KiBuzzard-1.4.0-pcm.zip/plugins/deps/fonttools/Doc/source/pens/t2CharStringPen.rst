###############
t2CharStringPen
###############

.. automodule:: fontTools.pens.t2CharStringPen
   :inherited-members:
   :members:
   :undoc-members:
