#######
basePen
#######

.. automodule:: fontTools.pens.basePen
   :inherited-members:
   :members:
   :undoc-members:
