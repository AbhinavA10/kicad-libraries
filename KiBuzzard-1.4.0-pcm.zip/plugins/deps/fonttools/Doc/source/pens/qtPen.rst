#####
qtPen
#####

.. automodule:: fontTools.pens.qtPen
   :inherited-members:
   :members:
   :undoc-members:
