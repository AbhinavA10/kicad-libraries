######
teePen
######

.. automodule:: fontTools.pens.teePen
   :inherited-members:
   :members:
   :undoc-members:
